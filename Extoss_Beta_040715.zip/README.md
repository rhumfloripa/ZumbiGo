# Haxius
A 2D shoot 'em up with tiled levels. Made with HaxeFlixel.

![alt tag](http://www.strandedsoft.com/contenidos/uploads/2015/02/Captura-de-pantalla-2015-02-21-a-las-13.09.06-900x563.png)

![alt tag](http://i.imgur.com/6AMZ9ng.gif)

Check out the step by step tutorial: http://www.strandedsoft.com/haxeflixel-tutorial-building-your-first-2d-shoot-em-up-part-i/

(Gradius music belongs to Konami Digital Entertainment Inc.)

