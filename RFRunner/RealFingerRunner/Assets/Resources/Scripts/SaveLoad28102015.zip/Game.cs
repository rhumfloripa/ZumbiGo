﻿using UnityEngine;
using System.Collections;

[System.Serializable]
public class Game
{

    public static Game current;
    public string score;

    public Game()
    {
        score = Score.score.text;
        current = this;
    }
}
